/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.notepad;

import java.awt.Color;
import javax.swing.JFrame;

/**
 *
 * @author muradnabizade
 */
public class NewClass {
    public static void main(String[] args){
        NewJFrame obj = new NewJFrame();
        obj.setBounds(0,0,700,700);
        obj.setTitle("NotePad");
        obj.setResizable(false);
        obj.setBackground(new Color(191, 128, 65));
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        obj.setVisible(true);

    }
    
}
